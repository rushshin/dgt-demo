# Troubleshooting

To troubleshoot the Collector, see the [Troubleshooting] page.

[Troubleshooting]: https://opentelemetry.io/docs/collector/troubleshooting/
