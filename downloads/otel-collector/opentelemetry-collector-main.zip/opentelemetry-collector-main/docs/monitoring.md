# Monitoring

To learn how to monitor the Collector using its own telemetry, see the [Internal
telemetry] page.

[Internal telemetry]:
  https://opentelemetry.io/docs/collector/internal-telemetry/#use-internal-telemetry-to-monitor-the-collector
