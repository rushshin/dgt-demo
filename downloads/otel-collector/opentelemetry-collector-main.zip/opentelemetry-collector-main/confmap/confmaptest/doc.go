// Copyright The OpenTelemetry Authors
// SPDX-License-Identifier: Apache-2.0

// Package confmaptest helps loading confmap.Conf to test packages implementing using the configuration.
package confmaptest // import "go.opentelemetry.io/collector/confmap/confmaptest"
