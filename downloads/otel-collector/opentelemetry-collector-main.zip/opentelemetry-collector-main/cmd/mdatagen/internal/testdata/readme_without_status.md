# Some component

Some info about a component
