# Examples

Information on how the examples can be used can be found in the [Getting
Started
documentation](https://opentelemetry.io/docs/collector/getting-started/).
