// Copyright The OpenTelemetry Authors
// SPDX-License-Identifier: Apache-2.0

// Package consumer contains interfaces that receive and process data.
package consumer // import "go.opentelemetry.io/collector/consumer"
